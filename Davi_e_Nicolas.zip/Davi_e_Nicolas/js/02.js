function butao(){
    alert("Deus te ama e nunca vai te abandonar");      
}  