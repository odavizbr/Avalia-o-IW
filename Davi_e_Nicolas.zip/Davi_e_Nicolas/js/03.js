document.querySelector("h5").style.backgroundColor = "pink";
// querySelector é utilizado para selecionar um elemento especifico que corresponde ao CSS/HTML

const nodeList = document.querySelectorAll(".teste");
// querySelector é utilizado para selecionar TODOS os elementos especificados que correspondem ao CSS/HTML

for (let i = 0; i < nodeList.length; i++) {
nodeList[i].style.backgroundColor = "powderblue";

const collection = document.getElementsByClassName("tst2");
// getElementsByClassName é utilizado para selecionar um determinado elemento pelo nome da class aplicada a ele

for (let i = 0; i < collection.length; i++) {
collection[i].style.backgroundColor = "yellow";
}

}

function som(){

let n01 = document.getElementById("n1");
// getElementById é utilizado para selecionar um determinado elemento pelo nome do id aplicado a ele

console.log(n01.value);
let n02 = document.getElementById("n2");


let soma = parseInt (n01.value) + parseInt(n02.value);

let resultado = document.getElementsByTagName("p");
//getElementsByTagName é utilizado para selecionar os elementos de uma determinada tag

resultado[0].innerHTML = soma;
}

function sub(){

    let n01 = document.getElementById("n1");
    console.log(n01.value);
    let n02 = document.getElementById("n2");


    let soma = parseInt (n01.value) - parseInt(n02.value);

    let resultado = document.getElementsByTagName("p");
    resultado[0].innerHTML = soma;
}


function divd(){

    let n01 = document.getElementById("n1");
    console.log(n01.value);
    let n02 = document.getElementById("n2");


    let soma = parseInt (n01.value) / parseInt(n02.value);

    let resultado = document.getElementsByTagName("p");
    resultado[0].innerHTML = soma;
}

function mult(){

    let n01 = document.getElementById("n1");
    console.log(n01.value);
    let n02 = document.getElementById("n2");


    let soma = parseInt (n01.value) * parseInt(n02.value);

    let resultado = document.getElementsByTagName("p");
    resultado[0].innerHTML = soma;
}