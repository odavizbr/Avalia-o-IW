function big(x) {
    x.style.height = "320px";
    x.style.width = "320px";
}

function normal(x) {
    x.style.height = "160px";
    x.style.width = "160px";
}

function cordfnd(x) {
    x.style.background = "tomato";
}

function frutas() {
    var x = document.getElementById("select").value;
    document.getElementById("esc").innerHTML = "Vc escolheu: " + x;
}

function myFunction() {
    document.getElementById("demo").innerHTML = "Olá! Tudo bem?";
}
